﻿using System;
using System.Net;
using System.IO;
using SharpEcho.Recruiting.SpellChecker.Contracts;
using SharpEcho.Recruiting.SpellChecker.Core;


using System.Security.Authentication;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace SharpEcho.Recruiting.SpellCheckerConsole
{
    /// <summary>
    /// Thank you for your interest in a position at SharpEcho.  The following are the "requirements" for this project:
    /// 
    /// 1. Implent Main() below so that a user can input a sentance.  Each word in that
    ///    sentance will be evaluated with the SpellChecker, which returns true for a word
    ///    that is spelled correctly and false for a word that is spelled incorrectly.  Display
    ///    out each *distnict* word that is misspelled.  That is, if a user uses the same misspelled
    ///    word more than once, simply output that word one time.
    ///    
    ///    Example:
    ///    Please enter a sentance: Salley sells seashellss by the seashore.  The shells Salley sells are surely by the sea.
    ///    Misspelled words: Salley seashellss
    ///    
    /// 2. The concrete implementation of SpellChecker depends on two other implementations of ISpellChecker, DictionaryDotComSpellChecker
    ///    and MnemonicSpellCheckerIBeforeE.  You will need to implement those classes.  See those classes for details.
    ///    
    /// 3. There are covering unit tests in the SharpEcho.Recruiting.SpellChecker.Tests library that should be implemented as well.
    /// </summary>
    /// 
    class Program
    {

        /// <summary>
        /// This application is intended to allow a user enter some text (a sentence)
        /// and it will display a distinct list of incorrectly spelled words
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            const SslProtocols _Tls12 = (SslProtocols)0x00000C00;
            const SecurityProtocolType Tls12 = (SecurityProtocolType)_Tls12;
            ServicePointManager.SecurityProtocol = Tls12;
            Console.Write("Please enter a sentance: ");
            var sentance = Console.ReadLine();


            sentance= Regex.Replace(sentance, @"\p{P}", " ");//strips punctuation from sentance 
            


            // first break the sentance up into words, 
            // then iterate through the list of words using the spell checker
            // capturing distinct words that are misspelled

            // use this spellChecker to evaluate the words

            // Add a user agent header in case the                placed in public class DictionaryDotComSpellChecker : ISpellChecker
            // requested URI contains a query.


            var spellChecker = new SpellChecker.Core.SpellChecker
                (
                    new ISpellChecker[]
                    {
                        new MnemonicSpellCheckerIBeforeE(),
                        new DictionaryDotComSpellChecker(),
                    }
                );
           
            List<String> missSpelled = new List<String>();
            string[] words = sentance.Split(null);
            for (int i = 0; i < words.Length; i++)
            {
                if (!spellChecker.Check(words[i]))
                {
                    if (!missSpelled.Contains(words[i]))
                    {
                        missSpelled.Add(words[i]);
                    }
                }
            }
            for (int i = 0; i < missSpelled.Count; i++) {
                Console.WriteLine(missSpelled[i]);
            }


            Console.ReadLine();




        }
    }
}
