﻿using NUnit.Framework;

using SharpEcho.Recruiting.SpellChecker.Contracts;
using SharpEcho.Recruiting.SpellChecker.Core;
using System.Net;
using System.Security.Authentication;

namespace SharpEcho.Recruiting.SpellChecker.Tests
{
    [TestFixture]
    class DictionaryDotComSpellCheckerTests
    {
        private ISpellChecker SpellChecker;

        [TestFixtureSetUp]
        public void TestFixureSetUp()
        {
            SpellChecker = new DictionaryDotComSpellChecker();
            const SslProtocols _Tls12 = (SslProtocols)0x00000C00;
            const SecurityProtocolType Tls12 = (SecurityProtocolType)_Tls12;
            ServicePointManager.SecurityProtocol = Tls12;

        }

        [Test]
        public void Check_That_SharpEcho_Is_Misspelled()
        {
            // implement this test
            Assert.That(SpellChecker.Check("SharpEcho"), Is.EqualTo(false));
        }

        [Test]
        public void Check_That_South_Is_Not_Misspelled()
        {
            // implement this test
            Assert.That(SpellChecker.Check("South"), Is.EqualTo(true));

        }
    }
}
