﻿using SharpEcho.Recruiting.SpellChecker.Contracts;
using System;
using System.Net;
using System.IO;
using System.Security.Authentication;

namespace SharpEcho.Recruiting.SpellChecker.Core
{
    /// <summary>
    /// This is a dictionary based spell checker that uses dictionary.com to determine if
    /// a word is spelled correctly
    /// 
    /// The URL to do this looks like this: http://dictionary.reference.com/browse/<word>
    /// where <word> is the word to be checked
    /// 
    /// Example: http://dictionary.reference.com/browse/SharpEcho would lookup the word SharpEcho
    /// 
    /// We look for something in the response that gives us a clear indication whether the
    /// word is spelled correctly or not
    /// </summary>
    public class DictionaryDotComSpellChecker : ISpellChecker
    {
        public bool Check(string word)
        {
            WebClient client = new WebClient();//if a 404 error is thrown then the web page doesnt exist ->the word is not on dictionary.com
            client.Headers.Add("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; .NET CLR 1.0.3705;)");
            try
            { 
                Stream data = client.OpenRead(("https://www.dictionary.com/browse/"+ word));
                data.Close();
                return true;
             
            }
            catch
            {
                
                return false;
            }





            throw new System.NotImplementedException();
        }
    }
}
